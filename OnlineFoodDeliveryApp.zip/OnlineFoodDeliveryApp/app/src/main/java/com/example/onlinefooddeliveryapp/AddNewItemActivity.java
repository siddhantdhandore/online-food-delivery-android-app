package com.example.onlinefooddeliveryapp;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class AddNewItemActivity extends AppCompatActivity {
    EditText et_itemName,et_itemFullPrice,et_itemHalfPrice,et_itemDescription;
    Button btn_chooseImage,btn_addNewItem;
    ImageView iv_imageSelected;

    Uri imageUri;
    ActivityResultLauncher<String> getContent;

    DatabaseReference databaseReference;
    StorageReference storageReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_item);

        databaseReference=FirebaseDatabase.getInstance().getReference("Items");

        et_itemName=(EditText) findViewById(R.id.et_itemName);
        et_itemFullPrice=(EditText) findViewById(R.id.et_itemFullPrice);
        et_itemHalfPrice=(EditText) findViewById(R.id.et_itemHalfPrice);
        et_itemDescription=(EditText) findViewById(R.id.et_itemDescription);
        btn_chooseImage=(Button) findViewById(R.id.btn_chooseImage);
        btn_addNewItem=(Button) findViewById(R.id.btn_addNewItem);
        iv_imageSelected=(ImageView) findViewById(R.id.iv_imageSelected);

        getContent=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri result) {
                imageUri=result;
                if(imageUri!=null){
                    iv_imageSelected.setImageURI(result);
                }else{
                    Toast.makeText(getApplicationContext(), "No Image Selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getContent.launch("image/*");
            }
        });

        btn_addNewItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //input validation
                validateInputData();

            }
        });
    }
    void validateInputData(){
        String itemName=et_itemName.getText().toString().trim();
        int itemFullPrice=Integer.valueOf(et_itemFullPrice.getText().toString().trim());
        int itemHalfPrice=Integer.valueOf(et_itemHalfPrice.getText().toString().trim());
        String itemDescription=et_itemDescription.getText().toString().trim();
        if(imageUri==null){
            Toast.makeText(getApplicationContext(), "Please Select Image", Toast.LENGTH_SHORT).show();
        }else if(itemName.length()==0 || itemFullPrice<=0 ||itemHalfPrice<=0|| itemDescription.length()==0){
            Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();

        }else if(itemFullPrice< itemHalfPrice){
            Toast.makeText(getApplicationContext(), "Full Price should be larger than half", Toast.LENGTH_SHORT).show();
        }else{
            uploadImage(itemName,itemFullPrice,itemHalfPrice,itemDescription);
        }
    }
    void uploadImage(String itemName, int itemFullPrice,int itemHalfPrice, String itemDescription){
        ProgressDialog progressDialog= new ProgressDialog(AddNewItemActivity.this);
        String itemId= databaseReference.push().getKey().toString();
        //1) add item into storage
        //2) get download url
        //3) add into firebase realtime database
        storageReference=FirebaseStorage.getInstance().getReference("uploads").child(itemId);
        storageReference.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        String downloadURI=uri.toString();
                        Item item = new Item(itemId,itemName,itemFullPrice,itemHalfPrice,itemDescription,true,downloadURI);
                        databaseReference.child(itemId).setValue(item);
                        progressDialog.dismiss();
                        AdminDashboardMenu.itemArrayList.add(item);

                        AdminDashboardMenu.itemArrayAdapter.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "Successfully inserted", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Please Wait...");
                progressDialog.show();
            }
        });
    }

}