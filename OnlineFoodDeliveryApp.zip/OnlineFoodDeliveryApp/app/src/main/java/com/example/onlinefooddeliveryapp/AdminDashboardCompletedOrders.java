package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AdminDashboardCompletedOrders extends AppCompatActivity {
    Button btn_adminMenuButton,btn_adminPendingOrdersButton,btn_adminStoreButton;
    ListView lv_allItems;
    AdminPendingOrdersAdapter adminCompletedOrdersAdapter;
    DatabaseReference completedOrdersDatabaseReference;
    ArrayList<CustomerOrder> completedOrderArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard_completed_orders);
        completedOrdersDatabaseReference=FirebaseDatabase.getInstance().getReference("CompletedOrders");

        btn_adminMenuButton=(Button) findViewById(R.id. btn_adminMenuButton);
        btn_adminPendingOrdersButton=(Button) findViewById(R.id.btn_adminPendingOrdersButton);
        btn_adminStoreButton=(Button) findViewById(R.id.btn_adminStoreButton);

        completedOrderArrayList= new ArrayList<CustomerOrder>();
        lv_allItems=(ListView) findViewById(R.id.lv_allItems);
        adminCompletedOrdersAdapter=new AdminPendingOrdersAdapter(this, R.layout.single_row_pending_orders,completedOrderArrayList);
        lv_allItems.setAdapter(adminCompletedOrdersAdapter);

        completedOrdersDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snp:snapshot.getChildren()){
                    String UID=snp.getKey();
                    completedOrdersDatabaseReference.child(UID).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            completedOrderArrayList.clear();
                            for(DataSnapshot snp:snapshot.getChildren()){
                                completedOrderArrayList.add(snp.getValue(CustomerOrder.class));
                            }
                            adminCompletedOrdersAdapter.notifyDataSetChanged();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        btn_adminMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardCompletedOrders.this, AdminDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });

        btn_adminPendingOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AdminDashboardCompletedOrders.this, AdminDashboardPendingOrders.class);
                startActivity(intent);
                finish();
            }
        });

        btn_adminStoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardCompletedOrders.this, AdminDashboardStore.class);
                startActivity(intent);
                finish();
            }
        });

    }
}