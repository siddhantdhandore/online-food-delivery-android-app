package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class AdminDashboardMenu extends AppCompatActivity {
    Button btn_adminPendingOrdersButton, btn_adminStoreButton,btn_adminCompletedOrdersButton, btn_addNewItemDialogOpener;
    DatabaseReference databaseReference;
    StorageReference storageReference;
    ListView lv_allItems;
    public static ArrayList<Item> itemArrayList;
    public static ItemAdapter itemArrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard_menu);

        lv_allItems=(ListView) findViewById(R.id.lv_allItems);
        itemArrayList= new ArrayList<Item>();
        itemArrayAdapter=new ItemAdapter(this,R.layout.single_row_item,itemArrayList);
        lv_allItems.setAdapter(itemArrayAdapter);
        registerForContextMenu(lv_allItems);

        databaseReference= FirebaseDatabase.getInstance().getReference("Items");
        storageReference= FirebaseStorage.getInstance().getReference("uploads");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                itemArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    itemArrayList.add(snp.getValue(Item.class));
                }
                itemArrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        btn_adminCompletedOrdersButton=(Button) findViewById(R.id. btn_adminCompletedOrdersButton);
        btn_adminPendingOrdersButton = (Button) findViewById(R.id.btn_adminPendingOrdersButton);
        btn_adminStoreButton = (Button) findViewById(R.id.btn_adminStoreButton);
        btn_addNewItemDialogOpener = (Button) findViewById(R.id.btn_addNewItemDialogOpener);

        btn_adminCompletedOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(AdminDashboardMenu.this, AdminDashboardCompletedOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_addNewItemDialogOpener.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //dialog box for adding new item into database
                Intent intent = new Intent(AdminDashboardMenu.this,AddNewItemActivity.class);
                startActivity(intent);
            }
        });

        btn_adminPendingOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardMenu.this, AdminDashboardPendingOrders.class);
                startActivity(intent);
                finish();
            }
        });


        btn_adminStoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardMenu.this, AdminDashboardStore.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.item_context_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String imageID=itemArrayList.get(info.position).id;
        int imagePosition=info.position;
        switch(item.getItemId()){
            case R.id.ctx_delete:
                AlertDialog.Builder builder= new AlertDialog.Builder(this);
                builder.setMessage("Are you sure to delete");
                builder.setCancelable(true);
                builder.create();

                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteEntryFromDatabase(imageID,imagePosition);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                break;
            case R.id.ctx_update:
                Intent intent = new Intent(AdminDashboardMenu.this,UpdateItemActivity.class);
                intent.putExtra("itemid",""+itemArrayList.get(imagePosition).id);
                intent.putExtra("itemName",""+itemArrayList.get(imagePosition).name);
                intent.putExtra("itemFullPrice",""+itemArrayList.get(imagePosition).fullPrice);
                intent.putExtra("itemHalfPrice",""+itemArrayList.get(imagePosition).halfPrice);
                intent.putExtra("itemDescription",""+itemArrayList.get(imagePosition).description);
                intent.putExtra("downloadURI",""+itemArrayList.get(imagePosition).downloadURI);
                startActivity(intent);
                break;
        }
        return super.onContextItemSelected(item);
    }
    void deleteEntryFromDatabase(String imageID,int imagePosition){
        databaseReference.child(imageID).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                storageReference.child(imageID).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), "successfully deleted", Toast.LENGTH_SHORT).show();
                        itemArrayList.remove(imagePosition);
                        itemArrayAdapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}