package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminDashboardPendingOrders extends AppCompatActivity {
    Button btn_adminMenuButton,btn_adminStoreButton,btn_adminCompletedOrdersButton;
    ListView lv_allItems;
    DatabaseReference pendingOrdersDatabaseReference,completedOrdersDatabaseReference;
    ArrayList<CustomerOrder> customerPendingOrderArrayList;
    AdminPendingOrdersAdapter adminPendingOrdersAdapter;
    ArrayList<User> userArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userArrayList= new ArrayList<User>();
        setContentView(R.layout.activity_admin_dashboard_pending_orders);
        btn_adminMenuButton=(Button) findViewById(R.id.btn_adminMenuButton);
        btn_adminStoreButton=(Button) findViewById(R.id.btn_adminStoreButton);
        btn_adminCompletedOrdersButton=(Button) findViewById(R.id.btn_adminCompletedOrdersButton);

        lv_allItems=(ListView) findViewById(R.id.lv_allItems);
        registerForContextMenu(lv_allItems);

        customerPendingOrderArrayList=new ArrayList<CustomerOrder>();

        adminPendingOrdersAdapter=new AdminPendingOrdersAdapter(this, R.layout.single_row_pending_orders, customerPendingOrderArrayList);


        lv_allItems.setAdapter(adminPendingOrdersAdapter);
        pendingOrdersDatabaseReference= FirebaseDatabase.getInstance().getReference("Orders");
        completedOrdersDatabaseReference=FirebaseDatabase.getInstance().getReference("CompletedOrders");

        pendingOrdersDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                customerPendingOrderArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    String customerId=snp.getKey().toString();
                    pendingOrdersDatabaseReference.child(customerId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for(DataSnapshot snp: snapshot.getChildren()){
                                CustomerOrder customerOrder=snp.getValue(CustomerOrder.class);
                                customerPendingOrderArrayList.add(customerOrder);
                            }
                            adminPendingOrdersAdapter.notifyDataSetChanged();
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError error) { }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });


        btn_adminCompletedOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardPendingOrders.this, AdminDashboardCompletedOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_adminStoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardPendingOrders.this,AdminDashboardStore.class);
                startActivity(intent);
                finish();
            }
        });

        btn_adminMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardPendingOrders.this,AdminDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.admin_order_operations_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String orderId=customerPendingOrderArrayList.get(info.position).id;
        int orderPosition=info.position;
        switch(item.getItemId()){
            case R.id.view_order_contents:
                viewOrderContents(orderPosition);
                break;
            case R.id.change_order_status:
                showChangeOrderStatusDialog(orderPosition);
                break;
            case R.id.view_other_data:
                showOtherData(orderPosition);
                //Toast.makeText(getApplicationContext(), "view_other_data\norderId "+orderId+"\norderPosition "+orderPosition, Toast.LENGTH_SHORT).show();
                break;

        }
        return super.onContextItemSelected(item);
    }
    void showOtherData(int orderPosition){
        CustomerOrder customerOrder=customerPendingOrderArrayList.get(orderPosition);
        ReadyForDeliveryOrder readyForDeliveryOrder= new ReadyForDeliveryOrder();

        readyForDeliveryOrder.id=customerOrder.id;
        readyForDeliveryOrder.deliveryAddress=customerOrder.deliveryAddress;
        readyForDeliveryOrder.orderStatus= customerOrder.orderStatus;
        readyForDeliveryOrder.grandTotalAmount=customerOrder.grandTotalAmount;

        FirebaseDatabase.getInstance().getReference("Users").child(customerOrder.UID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snp:snapshot.getChildren()){
                    switch (snp.getKey()){
                        case "mobile":
                            readyForDeliveryOrder.mobileNumber=snp.getValue().toString();
                            Toast.makeText(getApplicationContext(), snp.getValue().toString(), Toast.LENGTH_SHORT).show();
                            break;
                        case "name":
                            readyForDeliveryOrder.customerName=snp.getValue().toString();
                            Toast.makeText(getApplicationContext(), snp.getValue().toString(), Toast.LENGTH_SHORT).show();
                            break;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    void addOrderToCompletedOrders(int orderPosition){
        CustomerOrder customerOrder=customerPendingOrderArrayList.get(orderPosition);
        String UID=customerOrder.UID;
        pendingOrdersDatabaseReference.child(UID).child(customerOrder.id).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                completedOrdersDatabaseReference.child(UID).child(customerOrder.id).setValue(customerOrder).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        customerPendingOrderArrayList.remove(orderPosition);
                        Toast.makeText(getApplicationContext(), "Successfully removed", Toast.LENGTH_SHORT).show();
                        adminPendingOrdersAdapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    void createReadyForDelivery(int orderPosition,String newOrderStatus){
        CustomerOrder customerOrder=customerPendingOrderArrayList.get(orderPosition);
        ReadyForDeliveryOrder readyForDeliveryOrder= new ReadyForDeliveryOrder();

        readyForDeliveryOrder.id=customerOrder.id;
        readyForDeliveryOrder.deliveryAddress=customerOrder.deliveryAddress;
        readyForDeliveryOrder.orderStatus= newOrderStatus;
        readyForDeliveryOrder.grandTotalAmount=customerOrder.grandTotalAmount;
        readyForDeliveryOrder.UID=customerOrder.UID;
        readyForDeliveryOrder.dpid="";
        FirebaseDatabase.getInstance().getReference("Users").child(customerOrder.UID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snp:snapshot.getChildren()){
                    switch (snp.getKey()){
                        case "mobile":
                            readyForDeliveryOrder.mobileNumber=snp.getValue().toString();
                            break;
                        case "name":
                            readyForDeliveryOrder.customerName=snp.getValue().toString();
                            break;
                    }
                }
                addOrderIntoReady(readyForDeliveryOrder);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });



    }
    void addOrderIntoReady(ReadyForDeliveryOrder readyForDeliveryOrder){
        DatabaseReference readyForDeliveryDatabaseReference=FirebaseDatabase.getInstance().getReference("ReadyForDelivery");
        readyForDeliveryDatabaseReference.child(readyForDeliveryOrder.id).setValue(readyForDeliveryOrder).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "Order Added into ready for delivery", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    void changeOrderStatusInDatabase(String currentOrderStatus, String newOrderStatus,int orderPosition){
        CustomerOrder customerOrder=customerPendingOrderArrayList.get(orderPosition);
        String UID=customerOrder.UID;
        pendingOrdersDatabaseReference.child(UID).child(customerOrder.id).child("orderStatus").setValue(newOrderStatus).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                customerPendingOrderArrayList.get(orderPosition).orderStatus=newOrderStatus;
                adminPendingOrdersAdapter.notifyDataSetChanged();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    void showChangeOrderStatusDialog(int orderPosition){
        CustomerOrder customerOrder= customerPendingOrderArrayList.get(orderPosition);
        int deliveryOption=customerOrder.deliveryOption;
        String currentOrderStatus=customerOrder.orderStatus;
        String newOrderStatusMessage="";

        switch (currentOrderStatus){
            case "Sent To Restaurant":
                newOrderStatusMessage="Received By Restaurant";

                break;

            case "Received By Restaurant":
                newOrderStatusMessage="Preparing";

                break;

            case "Preparing":
                //1) home delivery 2) collect from restaurante
                if (deliveryOption==1){ // 1)home delivery
                    newOrderStatusMessage="Ready For Delivery";

                }else{                  // 2) collect from restaurant
                    newOrderStatusMessage="Collect From Restaurant";

                }
                break;

            case "Collect From Restaurant":
                newOrderStatusMessage="Collected From Restaurant";


                //0) remove order from pending orders.
                //1) add order to the completed orders in the completed orders in admin dashboard
                //2)add order to the completed orders in the customer dashboard
                //3) update earnings
                break;
            case "Collected From Restaurant":
                //addOrderToCompletedOrders(orderPosition);

                return;

            case "Ready For Delivery":
                //1)add the order in the readyForDelivery DAtabase


                //if the delivery person accepts the order. then change the order status from deliver persons dashboard. ("ASSIGNED TO DELIVERY PERSON")
                //if the order is delivered to the customer. change order status from deliver persons dashboard. ("DELIVERED")
                //if the night delivery person makes payment to restaurnat
                // then change the earnings of restaurnt.
                // the delivery person will do the next status changes.

                return;
            case "Assigned To Delivery Person":
                return;
            case "Delivery Person Picked Order":
                return;
//
//            case "Assigned To Delivery Person":
//                //assign the order to delivery person
//                newOrderStatusMessage="";
//                break;
//
//            case "In Transit":
//                newOrderStatusMessage="";
//                break;
//
//            case "Delivered":
//                newOrderStatusMessage="";
//                break;

        }

        String message="Current Order :"+currentOrderStatus+"\nNew Status :"+newOrderStatusMessage;

        AlertDialog.Builder builder= new AlertDialog.Builder(AdminDashboardPendingOrders.this);
        builder.setMessage(message);
        builder.create();

        String newOrderStatus=newOrderStatusMessage;

        builder.setPositiveButton("CHANGE STATUS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                changeOrderStatusInDatabase(currentOrderStatus,newOrderStatus,orderPosition);
                if (newOrderStatus.equals("Collected From Restaurant")){
                    addOrderToCompletedOrders(orderPosition);
                }else if(newOrderStatus.equals("Ready For Delivery")){
                    createReadyForDelivery(orderPosition,newOrderStatus);
                }
            }
        }).setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //
                Toast.makeText(getApplicationContext(), "Canceled", Toast.LENGTH_SHORT).show();

            }
        });
        builder.show();

    }

    void viewOrderContents(int position){

        StringBuffer stringBuffer= new StringBuffer();
        CustomerOrder customerOrder=customerPendingOrderArrayList.get(position);
        ArrayList<CartItem> cartItemArrayList= customerOrder.cartItemArrayList;

        stringBuffer.append("---ITEMS---\n");
        for(CartItem cartItem:cartItemArrayList){
            stringBuffer.append("Item :"+cartItem.name+" ");
            stringBuffer.append(""+cartItem.quantity+" ");

            if(cartItem.halfOrFull==1){
                stringBuffer.append("Half\n");
            }else{
                stringBuffer.append("Full\n");
            }
            stringBuffer.append("Note : "+cartItem.note+"\n\n");
        }
        AlertDialog.Builder builder= new AlertDialog.Builder(AdminDashboardPendingOrders.this);
        builder.setCancelable(true);
        builder.setMessage(stringBuffer.toString());
        builder.create();
        builder.show();
    }
}