package com.example.onlinefooddeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class AdminDashboardStore extends AppCompatActivity {
    Button btn_adminMenuButton,btn_adminPendingOrdersButton,btn_logout,btn_adminCompletedOrdersButton;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard_store);
        firebaseAuth=FirebaseAuth.getInstance();

        btn_adminMenuButton=(Button) findViewById(R.id.btn_adminMenuButton);
        btn_adminPendingOrdersButton=(Button) findViewById(R.id.btn_adminPendingOrdersButton);
        btn_adminCompletedOrdersButton=(Button) findViewById(R.id. btn_adminCompletedOrdersButton);

        btn_logout=(Button)findViewById(R.id.btn_logout);

        btn_adminCompletedOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardStore.this, AdminDashboardCompletedOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(AdminDashboardStore.this,MainActivity.class);
                startActivity(intent);
                finish();
                firebaseAuth.signOut();
            }
        });
        btn_adminMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardStore.this, AdminDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });

        btn_adminPendingOrdersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminDashboardStore.this, AdminDashboardPendingOrders.class);
                startActivity(intent);
                finish();
            }
        });

    }
}