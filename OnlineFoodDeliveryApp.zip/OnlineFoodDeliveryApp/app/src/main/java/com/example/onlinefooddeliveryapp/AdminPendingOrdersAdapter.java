package com.example.onlinefooddeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdminPendingOrdersAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<CustomerOrder> customerOrderArrayList;

    public AdminPendingOrdersAdapter(Context context, int resource, ArrayList<CustomerOrder> customerOrderArrayList) {
        super(context, resource, customerOrderArrayList);
        this.context = context;
        this.resource = resource;
        this.customerOrderArrayList = customerOrderArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = layoutInflater.inflate(this.resource, parent, false);
        }

        TextView tv_orderId=(TextView) v.findViewById(R.id.tv_orderId);
        TextView tv_grandTotal=(TextView) v.findViewById(R.id.tv_grandTotal);
        TextView tv_orderStatus=(TextView) v.findViewById(R.id.tv_orderStatus);
        TextView tv_cartItemString=(TextView) v.findViewById(R.id.tv_cartItemString);

        tv_orderId.setText("Order Id : #"+customerOrderArrayList.get(position).id);
        tv_grandTotal.setText("Grand total Amount : "+customerOrderArrayList.get(position).grandTotalAmount);
        tv_orderStatus.setText("Status : "+customerOrderArrayList.get(position).orderStatus);
        tv_cartItemString.setText(customerOrderArrayList.get(position).cartItemString);

        return v;
    }
}
