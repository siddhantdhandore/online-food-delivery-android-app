package com.example.onlinefooddeliveryapp;

public class CartItem {
    String Id;
    int quantity;
    int halfOrFull;
    String note;
    int itemTotalPrice;
    String name;

    public CartItem(){
        //
    }

    public CartItem(String Id, String name,int quantity, int halfOrFull, String note, int itemTotalPrice) {
        this.Id = Id;
        this.name=name;
        this.quantity = quantity;
        this.halfOrFull = halfOrFull;
        this.note = note;
        this.itemTotalPrice = itemTotalPrice;
    }

    public String getItemId() {
        return Id;
    }

    public void setItemId(String Id) {
        this.Id = Id;
    }

    public String getItemName() {
        return this.name;
    }

    public void setItemName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int isHalfOrFull() {
        return halfOrFull;
    }

    public void setHalfOrFull(int halfOrFull) {
        this.halfOrFull = halfOrFull;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public int getItemTotalPrice() {
        return itemTotalPrice;
    }

    public void setItemTotalPrice(int itemTotalPrice) {
        this.itemTotalPrice = itemTotalPrice;
    }
}
