package com.example.onlinefooddeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CartItemAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<CartItem> cartItemArrayList;

    public CartItemAdapter( Context context, int resource,ArrayList<CartItem> cartItemArrayList) {
        super(context, resource, cartItemArrayList);
        this.context = context;
        this.resource = resource;
        this.cartItemArrayList = cartItemArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v=convertView;
        if (v==null){
            LayoutInflater layoutInflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=layoutInflater.inflate(this.resource,parent,false);
        }


        TextView tv_cartItemName=(TextView) v.findViewById(R.id.tv_cartItemName);
        TextView tv_cartItemQuantityHF=(TextView) v.findViewById(R.id.tv_cartItemQuantityHF);
        TextView tv_cartItemTotalPrice=(TextView) v.findViewById(R.id.tv_cartItemTotalPrice);

        tv_cartItemName.setText(cartItemArrayList.get(position).name);
        String quantityHF="Quantity : ";
        quantityHF+=cartItemArrayList.get(position).quantity;
        if(cartItemArrayList.get(position).halfOrFull==1){
            quantityHF+=" Half";
        }else{
            quantityHF+=" Full";
        }

        tv_cartItemQuantityHF.setText(quantityHF);
        tv_cartItemTotalPrice.setText("Total Price : "+cartItemArrayList.get(position).itemTotalPrice);

        return v;
    }
}
