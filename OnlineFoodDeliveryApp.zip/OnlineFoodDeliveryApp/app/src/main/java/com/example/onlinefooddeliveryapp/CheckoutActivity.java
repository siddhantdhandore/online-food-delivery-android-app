package com.example.onlinefooddeliveryapp;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class CheckoutActivity extends AppCompatActivity {
    DatabaseReference cartDatabaseReference;
    FirebaseAuth firebaseAuth;
    RadioButton rb_homeDelivery,rb_collectFromRestaurant;
    EditText et_deliveryAddress;
    TextView tv_orderSummary,tv_grandTotal,tv_paymentMethod;
    Button btn_placeOrder;
    LinearLayout btn_paymentMethod;
    public static StringBuffer orderSummary;
    public static int grandTotalAmount=0;
    public static int deliveryOption=1; // 1= home delivery, 2=collect from restaurant
    public static int paymentOption=1; //1= cash on delivery, 2=online payment
    ArrayList<CartItem> cartItemArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        orderSummary=new StringBuffer();
        cartItemArrayList= new ArrayList<CartItem>();
        tv_orderSummary=(TextView) findViewById(R.id.tv_orderSummary);
        tv_grandTotal=(TextView) findViewById(R.id.tv_grandTotal);
        btn_placeOrder=(Button) findViewById(R.id.btn_placeOrder);
        btn_paymentMethod=(LinearLayout) findViewById(R.id.btn_paymentMethod);
        tv_paymentMethod=(TextView) findViewById(R.id.tv_paymentMethod);
        rb_homeDelivery=(RadioButton) findViewById(R.id.rb_homeDelivery);
        rb_collectFromRestaurant=(RadioButton) findViewById(R.id.rb_collectFromRestaurant);
        et_deliveryAddress=(EditText) findViewById(R.id.et_deliveryAddress);

        firebaseAuth=FirebaseAuth.getInstance();
        String UID=firebaseAuth.getUid();
        cartDatabaseReference= FirebaseDatabase.getInstance().getReference("Carts").child(UID);

        cartDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cartItemArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    CartItem cartItem= snp.getValue(CartItem.class);
                    cartItemArrayList.add(cartItem);
                    orderSummary.append(cartItem.getItemName()+" "+cartItem.itemTotalPrice+"Rs.\n");
                    grandTotalAmount+=cartItem.itemTotalPrice;
                }

                tv_orderSummary.setText(orderSummary.toString());
                tv_grandTotal.setText("Grand Total : "+grandTotalAmount+"Rs");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        rb_collectFromRestaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deliveryOption=2;
                et_deliveryAddress.setText("Restaurant");
                et_deliveryAddress.setEnabled(false);
            }
        });

        rb_homeDelivery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deliveryOption=1;
                et_deliveryAddress.setText(" ");
                et_deliveryAddress.setEnabled(true);
            }
        });

        btn_paymentMethod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "payment method selected", Toast.LENGTH_SHORT).show();
            }
        });

        btn_placeOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String deliveryAddress=et_deliveryAddress.getText().toString();
                if(deliveryOption==1 && deliveryAddress.length()<30){
                    Toast.makeText(getApplicationContext(), "Address Length Should be at least 30 chars", Toast.LENGTH_SHORT).show();
                }else {

                    AlertDialog.Builder builder= new AlertDialog.Builder(CheckoutActivity.this);
                    builder.setCancelable(false);
                    builder.setMessage("Are you sure?"+deliveryOption);
                    builder.create();

                    builder.setPositiveButton("Place Order", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            //1)insert into database
                            String cartItemString="Items : ";
                            for( CartItem cartItem :cartItemArrayList){
                                cartItemString+=cartItem.name+",";
                            }
                            CustomerOrder customerOrder= new CustomerOrder("0",UID,deliveryAddress,cartItemString,cartItemArrayList,deliveryOption,paymentOption,"Sent To Restaurant","0",grandTotalAmount,"0");
                            addOrderToDatabase(customerOrder);

                            //2) delete cart
                            //3) go back to cart


                        }
                    }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //
                        }
                    });
                    builder.show();
                }

            }
        });




    }
    void deleteAllItemsFromCart(){
        cartDatabaseReference.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                cartItemArrayList.clear();
                Intent intent =  new Intent(CheckoutActivity.this,CustomerDashboardMenu.class);
                startActivity(intent);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    void addOrderToDatabase(CustomerOrder customerOrder){
        DatabaseReference orderDatabaseReference= FirebaseDatabase.getInstance().getReference("Orders").child(customerOrder.UID);
        String orderId=orderDatabaseReference.push().getKey();
        customerOrder.id=orderId;
        orderDatabaseReference.child(orderId).setValue(customerOrder).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                orderSummary.delete(0,orderSummary.length());
                deliveryOption=1;
                grandTotalAmount=0;
                deleteAllItemsFromCart();
                Toast.makeText(getApplicationContext(), "Successfully placed Order", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
}