package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CustomerDashboardCart extends AppCompatActivity {
    Button btn_customerOrderButton,btn_customerCartButton,btn_customerProfileButton,btn_customerMenuButton,btn_deleteAll,btn_checkout;
    ListView lv_allItems;
    ArrayList<CartItem> cartItemArrayList;
    CartItemAdapter cartItemAdapter;
    DatabaseReference cartDatabaseReference;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard_cart);

        firebaseAuth=FirebaseAuth.getInstance();
        String UID=firebaseAuth.getUid();
        cartDatabaseReference= FirebaseDatabase.getInstance().getReference("Carts").child(UID);

        lv_allItems=(ListView) findViewById(R.id.lv_allItems);

        cartItemArrayList=new ArrayList<CartItem>();

        cartItemAdapter= new CartItemAdapter(this,R.layout.single_row_cart_item, cartItemArrayList);
        lv_allItems.setAdapter(cartItemAdapter);
        registerForContextMenu(lv_allItems);

        cartDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cartItemArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    cartItemArrayList.add(snp.getValue(CartItem.class));
                }
                cartItemAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });






        btn_customerOrderButton=(Button)  findViewById(R.id.btn_customerOrderButton);
        btn_customerMenuButton=(Button) findViewById(R.id.btn_customerMenuButton);
        btn_customerProfileButton=(Button) findViewById(R.id.btn_customerProfileButton);
        btn_deleteAll=(Button) findViewById(R.id.btn_deleteAll);
        btn_checkout=(Button) findViewById(R.id.btn_checkout);
        btn_deleteAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAllItemsFromCart();
            }
        });

        btn_customerOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardCart.this,CustomerDashboardOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardCart.this,CustomerDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardCart.this,CustomerDashboardProfile.class);
                startActivity(intent);
                finish();
            }
        });
        btn_checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cartItemArrayList.size()!=0){
                    Intent intent = new Intent(CustomerDashboardCart.this, CheckoutActivity.class);

                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "Please Add items in Cart", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.item_context_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String cartItemId=cartItemArrayList.get(info.position).Id;
        int cartItemPosition=info.position;
        switch(item.getItemId()){
            case R.id.ctx_delete:
                AlertDialog.Builder builder= new AlertDialog.Builder(this);
                builder.setMessage("Are you sure to delete");
                builder.setCancelable(true);
                builder.create();

                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteEntryFromDatabase(cartItemId,cartItemPosition);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                break;
            case R.id.ctx_update:
                break;
        }
        return super.onContextItemSelected(item);
    }
    void deleteEntryFromDatabase(String cartItemId,int cartItemPosition){
        cartDatabaseReference.child(cartItemId).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "SuccessFully Deleted Item From cart", Toast.LENGTH_SHORT).show();
                cartItemArrayList.remove(cartItemPosition);
                cartItemAdapter.notifyDataSetChanged();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    void deleteAllItemsFromCart(){
        cartDatabaseReference.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                if (cartItemArrayList.size()==0){
                    Toast.makeText(getApplicationContext(), "Cart is already empty.", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Successfully delted all items", Toast.LENGTH_SHORT).show();
                    cartItemArrayList.clear();
                    cartItemAdapter.notifyDataSetChanged();
                }

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}