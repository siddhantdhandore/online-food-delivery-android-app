package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class CustomerDashboardMenu extends AppCompatActivity {
    Button btn_customerOrderButton,btn_customerCartButton,btn_customerProfileButton,btn_customerMenuButton;
    ListView lv_allItems;

    public static ArrayList<Item> itemArrayList;
    public static CustomerItemAdapter customerItemAdapter;
    int totalPrice;
    Dialog dialog;
    DatabaseReference databaseReference;
    FirebaseAuth firebaseAuth;
    public static int quantity;
    public static int halfOrFull; //1=half 2=full
    public static String itemNote;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard_menu);
        databaseReference= FirebaseDatabase.getInstance().getReference("Items");
        firebaseAuth=FirebaseAuth.getInstance();
        lv_allItems=(ListView) findViewById(R.id.lv_allItems);
        itemArrayList= new ArrayList<Item>();
        customerItemAdapter=new CustomerItemAdapter(this,R.layout.single_row_customer_item,itemArrayList);
        lv_allItems.setAdapter(customerItemAdapter);

        lv_allItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //openAddToCartDialog
                openAddToCartDialog(itemArrayList.get(position));
            }
        });

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProgressDialog dialog = new ProgressDialog(CustomerDashboardMenu.this);
                dialog.setMessage("Please Wait menu is loading...!");
                dialog.setCancelable(false);
                dialog.create();
                dialog.show();
                itemArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    itemArrayList.add(snp.getValue(Item.class));
                }
                dialog.dismiss();
                customerItemAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        btn_customerOrderButton=(Button)  findViewById(R.id.btn_customerOrderButton);
        btn_customerCartButton=(Button) findViewById(R.id.btn_customerCartButton);
        btn_customerProfileButton=(Button) findViewById(R.id.btn_customerProfileButton);

        btn_customerOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardMenu.this,CustomerDashboardOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardMenu.this,CustomerDashboardCart.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardMenu.this,CustomerDashboardProfile.class);
                startActivity(intent);
                finish();
            }
        });

    }
    void openAddToCartDialog(Item item){
        dialog = new Dialog(CustomerDashboardMenu.this);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.add_item_to_cart);
        dialog.show();

        TextView tv_itemName=(TextView)dialog.findViewById(R.id.tv_itemName);
        Spinner quantitySpinner=(Spinner) dialog.findViewById(R.id.spinnerQuantity);

        RadioButton rb_halfPrice=(RadioButton) dialog.findViewById(R.id.rb_halfPrice);
        RadioButton rb_fullPrice=(RadioButton) dialog.findViewById(R.id.rb_fullPrice);
        EditText et_note=(EditText) dialog.findViewById(R.id.et_note);
        TextView tv_totalPriceOfSelectedItems=(TextView) dialog.findViewById(R.id. tv_totalPriceOfSelectedItems);
        Button btn_addToCart=(Button) dialog.findViewById(R.id.btn_addToCart);

        tv_itemName.setText(item.name);
        halfOrFull=2;
        rb_halfPrice.setText("Half Price : "+item.halfPrice);
        rb_fullPrice.setText("Full Price : "+item.fullPrice);


        rb_fullPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity=Integer.parseInt(""+quantitySpinner.getSelectedItem());
                halfOrFull=2;
                displayPrice(dialog,quantity,item);
            }
        });

        rb_halfPrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                quantity=Integer.parseInt(""+quantitySpinner.getSelectedItem());
                halfOrFull=1;
                displayPrice(dialog,quantity,item);
            }
        });
        quantitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                quantity=Integer.parseInt(""+quantitySpinner.getSelectedItem());
                displayPrice(dialog,quantity,item);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //
            }
        });
        btn_addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //add item to cart
                itemNote = et_note.getText().toString();
//                StringBuffer buffer= new StringBuffer();
//                buffer.append("itemid"+item.id+"\n");
//                buffer.append("quantity"+quantity+"\n");
//                buffer.append("halfOrFull"+halfOrFull+"\n");
//                buffer.append("note"+itemNote+"\n");
//                buffer.append("totalPrice"+totalPrice+"\n");
//                Log.i("buffer",buffer.toString());
//                Toast.makeText(getApplicationContext(), ""+buffer.toString(), Toast.LENGTH_LONG).show();
                CartItem cartItem= new CartItem(item.id,item.name,quantity,halfOrFull,itemNote,totalPrice);
                addItemToCart(cartItem);
            }
        });
    }

    void displayPrice(Dialog dialog, int quantity, Item item){

        if(halfOrFull==1){
            totalPrice=item.getHalfPrice()*quantity;
        }else{
            totalPrice=item.getFullPrice()*quantity;
        }
        ((TextView)dialog.findViewById(R.id.tv_totalPriceOfSelectedItems)).
                setText("TotalPrice : "+totalPrice);
    }
    void addItemToCart(CartItem cartItem){
        ProgressDialog progressDialog = new ProgressDialog(CustomerDashboardMenu.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();
        String userId=firebaseAuth.getUid();
        DatabaseReference cartDatabaseRefernce= FirebaseDatabase.getInstance().getReference("Carts").child(userId);
        cartDatabaseRefernce.child(cartItem.Id).setValue(cartItem).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                progressDialog.dismiss();
                dialog.dismiss();
                Toast.makeText(getApplicationContext(), "successfully added to cart", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}