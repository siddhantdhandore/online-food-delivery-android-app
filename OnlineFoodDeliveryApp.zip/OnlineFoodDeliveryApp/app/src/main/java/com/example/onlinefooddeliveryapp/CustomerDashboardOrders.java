package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CustomerDashboardOrders extends AppCompatActivity {
    Button btn_customerOrderButton,btn_customerCartButton,btn_customerProfileButton,btn_customerMenuButton;
    ListView lv_pendingOrders,lv_completedOrders;
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference,completedOrderDatabaseReference;
    ArrayList<CustomerOrder> customerOrderArrayList;
    ArrayList<CustomerOrder> customerCompletedOrderArrayList;
    PendingOrderAdapter pendingOrderAdapter;
    PendingOrderAdapter completedOrderAdapter;
    String UID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard_orders);
        firebaseAuth=FirebaseAuth.getInstance();
        UID= firebaseAuth.getUid();


        btn_customerCartButton=(Button)  findViewById(R.id.btn_customerCartButton);
        btn_customerMenuButton=(Button) findViewById(R.id.btn_customerMenuButton);
        btn_customerProfileButton=(Button) findViewById(R.id.btn_customerProfileButton);
        lv_completedOrders=(ListView) findViewById(R.id. lv_completedOrders);

        lv_pendingOrders=(ListView) findViewById(R.id.lv_pendingOrders);
        customerOrderArrayList=new ArrayList<CustomerOrder>();
        customerCompletedOrderArrayList= new ArrayList<CustomerOrder>();
        completedOrderAdapter= new PendingOrderAdapter(this,R.layout.customer_side_order_layout,customerCompletedOrderArrayList);
        pendingOrderAdapter= new PendingOrderAdapter(this,R.layout.customer_side_order_layout,customerOrderArrayList);
        lv_pendingOrders.setAdapter(pendingOrderAdapter);
        lv_completedOrders.setAdapter(completedOrderAdapter);
        completedOrderDatabaseReference=FirebaseDatabase.getInstance().getReference("CompletedOrders").child(UID);
        databaseReference= FirebaseDatabase.getInstance().getReference("Orders").child(UID);

        completedOrderDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                customerCompletedOrderArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    customerCompletedOrderArrayList.add(snp.getValue(CustomerOrder.class));
                }
                completedOrderAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                customerOrderArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    CustomerOrder customerOrder=snp.getValue(CustomerOrder.class);
                    customerOrderArrayList.add(customerOrder);


                }
                pendingOrderAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        btn_customerCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardOrders.this,CustomerDashboardCart.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardOrders.this,CustomerDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardOrders.this,CustomerDashboardProfile.class);
                startActivity(intent);
                finish();
            }
        });
    }
}