package com.example.onlinefooddeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class CustomerDashboardProfile extends AppCompatActivity {
    Button btn_customerOrderButton,btn_customerCartButton,btn_customerProfileButton,btn_customerMenuButton,btn_logout;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard_profile);
        firebaseAuth=FirebaseAuth.getInstance();
        btn_customerCartButton=(Button)  findViewById(R.id.btn_customerCartButton);
        btn_customerMenuButton=(Button) findViewById(R.id.btn_customerMenuButton);
        btn_customerOrderButton=(Button) findViewById(R.id.btn_customerOrderButton);
        btn_logout=(Button) findViewById(R.id. btn_logout);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(CustomerDashboardProfile.this,MainActivity.class);
                startActivity(intent);
                finish();
                firebaseAuth.signOut();
            }
        });
        btn_customerOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardProfile.this,CustomerDashboardOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardProfile.this,CustomerDashboardMenu.class);
                startActivity(intent);
                finish();
            }
        });
        btn_customerCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(CustomerDashboardProfile.this,CustomerDashboardCart.class);
                startActivity(intent);
                finish();
            }
        });
    }
}