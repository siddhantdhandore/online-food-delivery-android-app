package com.example.onlinefooddeliveryapp;

import java.util.ArrayList;

public class CustomerOrder {
    String id;
    String UID;
    String deliveryAddress;
    ArrayList<CartItem> cartItemArrayList;
    int deliveryOption;
    int paymentOption;
    String orderStatus;
    String orderDate;
    int grandTotalAmount;
    String paymentStatus;
    String cartItemString;
    public CustomerOrder() {

    }

    public CustomerOrder(String id, String UID, String deliveryAddress,String cartItemString, ArrayList<CartItem> cartItemArrayList, int deliveryOption, int paymentOption, String orderStatus, String orderDate, int grandTotalAmount, String paymentStatus) {
        this.id = id;
        this.UID = UID;
        this.cartItemArrayList = cartItemArrayList;
        this.deliveryAddress=deliveryAddress;
        this.cartItemString=cartItemString;
        this.deliveryOption = deliveryOption;
        this.paymentOption = paymentOption;
        this.orderStatus = orderStatus;
        this.orderDate = orderDate;
        this.grandTotalAmount = grandTotalAmount;
        this.paymentStatus = paymentStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getDeliveryAddress(){
        return this.deliveryAddress;
    }
    public void setDeliveryAddress(String deliveryAddress){
        this.deliveryAddress=deliveryAddress;
    }
    public ArrayList<CartItem> getCartItemArrayList() {
        return cartItemArrayList;
    }

    public void setCartItemArrayList(ArrayList<CartItem> cartItemArrayList) {
        this.cartItemArrayList = cartItemArrayList;
    }

    public String getCartItemString(){
        return this.cartItemString;
    }
    public void setCartItemString(String cartItemString){
        this.cartItemString=cartItemString;
    }

    public int getDeliveryOption() {
        return deliveryOption;
    }

    public void setDeliveryOption(int deliveryOption) {
        this.deliveryOption = deliveryOption;
    }

    public int getPaymentOption() {
        return paymentOption;
    }

    public void setPaymentOption(int paymentOption) {
        this.paymentOption = paymentOption;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public int getGrandTotalAmount() {
        return grandTotalAmount;
    }

    public void setGrandTotalAmount(int grandTotalAmount) {
        this.grandTotalAmount = grandTotalAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}
