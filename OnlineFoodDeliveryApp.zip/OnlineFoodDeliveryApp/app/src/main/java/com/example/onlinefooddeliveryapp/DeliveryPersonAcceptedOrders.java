package com.example.onlinefooddeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DeliveryPersonAcceptedOrders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_person_accepted_orders);
    }
}