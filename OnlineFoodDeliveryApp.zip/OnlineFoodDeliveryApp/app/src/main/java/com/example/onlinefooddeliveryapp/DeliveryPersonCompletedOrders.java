package com.example.onlinefooddeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class DeliveryPersonCompletedOrders extends AppCompatActivity {
    Button btn_deliveryPendingButton,btn_deliveryProfileButton;
    ListView lv_allItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_person_completed_orders);
        btn_deliveryPendingButton=(Button) findViewById(R.id.btn_deliveryPendingOrdersButton);
        btn_deliveryProfileButton=(Button) findViewById(R.id.btn_deliveryProfileButton);
        lv_allItems=(ListView) findViewById(R.id.lv_allItems);

        btn_deliveryPendingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonCompletedOrders.this,DeliveryPersonPendingOrders.class);
                startActivity(intent);
                finish();
            }
        });
        btn_deliveryProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonCompletedOrders.this, DeliveryPersonProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}