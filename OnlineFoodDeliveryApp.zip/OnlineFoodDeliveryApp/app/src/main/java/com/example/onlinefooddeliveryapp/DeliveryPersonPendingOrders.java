package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DeliveryPersonPendingOrders extends AppCompatActivity {
    Button btn_deliveryCompletedButton,btn_deliveryProfileButton;
    ListView lv_allItems,lv_acceptedOrders;
    ArrayList<ReadyForDeliveryOrder> readyForDeliveryOrderArrayList,acceptedOrderArrayList;
    ReadyForDeliveryOrderAdapter readyForDeliveryOrderAdapter,acceptedOrdersAdapter;
    String currentDpid;
    DatabaseReference readyForDeliveryDatabaseReference,acceptedOrdersDatabaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_person_pending_orders);
        currentDpid=FirebaseAuth.getInstance().getUid();
        btn_deliveryCompletedButton=(Button) findViewById(R.id. btn_deliveryCompletedOrdersButton);
        btn_deliveryProfileButton=(Button) findViewById(R.id.btn_deliveryProfileButton);

        lv_allItems=(ListView) findViewById(R.id.lv_allItems);
        lv_acceptedOrders=(ListView) findViewById(R.id.lv_acceptedOrders);

        readyForDeliveryOrderArrayList=new ArrayList<ReadyForDeliveryOrder>();
        acceptedOrderArrayList= new ArrayList<ReadyForDeliveryOrder>();

        readyForDeliveryOrderAdapter=new ReadyForDeliveryOrderAdapter(this,R.layout.single_row_delivery_pending,readyForDeliveryOrderArrayList);
        acceptedOrdersAdapter= new ReadyForDeliveryOrderAdapter(this, R.layout.single_row_delivery_pending,acceptedOrderArrayList);

        lv_allItems.setAdapter(readyForDeliveryOrderAdapter);
        lv_acceptedOrders.setAdapter(acceptedOrdersAdapter);
        registerForContextMenu(lv_allItems);
        readyForDeliveryDatabaseReference= FirebaseDatabase.getInstance().getReference("ReadyForDelivery");
        acceptedOrdersDatabaseReference=FirebaseDatabase.getInstance().getReference("ReadyForDelivery");




        acceptedOrdersDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                acceptedOrderArrayList.clear();
                for (DataSnapshot snp:snapshot.getChildren()){
                    ReadyForDeliveryOrder readyForDeliveryOrder=snp.getValue(ReadyForDeliveryOrder.class);
                    if( currentDpid.equals(readyForDeliveryOrder.dpid)){
                        acceptedOrderArrayList.add(readyForDeliveryOrder);
                    }
                    acceptedOrdersAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        readyForDeliveryDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                readyForDeliveryOrderArrayList.clear();
                for(DataSnapshot snp:snapshot.getChildren()){
                    ReadyForDeliveryOrder readyForDeliveryOrder=snp.getValue(ReadyForDeliveryOrder.class);
                    if(readyForDeliveryOrder.dpid.equals("")){
                        readyForDeliveryOrderArrayList.add(snp.getValue(ReadyForDeliveryOrder.class));
                    }

                }
                readyForDeliveryOrderAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        lv_acceptedOrders.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                showChangeOrderStatusDialog(position);
            }
        });


        btn_deliveryCompletedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonPendingOrders.this, DeliveryPersonCompletedOrders.class);
                startActivity(intent);
                finish();
            }
        });

        btn_deliveryProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonPendingOrders.this, DeliveryPersonProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    void showChangeOrderStatusDialog(int orderPosition){
        ReadyForDeliveryOrder acceptedOrder=acceptedOrderArrayList.get(orderPosition);
        String currentOrderStatus=acceptedOrder.orderStatus;
        String newOrderStatusMessage="";
        switch (currentOrderStatus){
            case "Assigned To Delivery Person":
                newOrderStatusMessage="Delivery Person Picked Order";
                break;
            case "Delivery Person Picked Order":
                newOrderStatusMessage="Delivered";
                break;
            default:
                return;
        }

        String newOrderStatus=newOrderStatusMessage;
        String message="Current Status :"+currentOrderStatus+"\nnew Status :"+newOrderStatusMessage;
        AlertDialog.Builder builder= new AlertDialog.Builder(DeliveryPersonPendingOrders.this);
        builder.setMessage(message);
        builder.create();
        builder.setPositiveButton("CHANGE STATUS", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(newOrderStatus.equals("Delivery Person Picked Order")){
                    pickOrder(orderPosition,newOrderStatus);
                }else if(newOrderStatus.equals("Delivered")){
                    deliverOrderToUser(orderPosition,newOrderStatus);
                }
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "Disagrees", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }
    void addOrderToCompletedDatabase(int orderPosition){
        ReadyForDeliveryOrder acceptedOrder= acceptedOrderArrayList.get(orderPosition);

        FirebaseDatabase.getInstance().getReference("Orders").child(acceptedOrder.UID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot snp:snapshot.getChildren()){
                    if(snp.getKey().equals(acceptedOrder.id)){
                        CustomerOrder customerOrder= snp.getValue(CustomerOrder.class);
                        FirebaseDatabase.getInstance().getReference("CompletedOrders").child(acceptedOrder.UID)
                                .child(acceptedOrder.id).setValue(customerOrder).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                FirebaseDatabase.getInstance().getReference("Orders").child(acceptedOrder.UID)
                                        .child(acceptedOrder.id).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        FirebaseDatabase.getInstance().getReference("DPOrders").child(acceptedOrder.dpid)
                                                .child(acceptedOrder.id).setValue(acceptedOrder.grandTotalAmount);
                                        FirebaseDatabase.getInstance().getReference("ReadyForDelivery").child(acceptedOrder.id)
                                                .removeValue();
                                        Toast.makeText(getApplicationContext(), "Successfully delivered", Toast.LENGTH_SHORT).show();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(), ""+e.toString(), Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), ""+error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    void deliverOrderToUser(int orderPosition,String newOrderStatus){
        ReadyForDeliveryOrder acceptedOrder=acceptedOrderArrayList.get(orderPosition);
        FirebaseDatabase.getInstance().getReference("ReadyForDelivery").child(acceptedOrder.id)
                .child("orderStatus").setValue(newOrderStatus).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                FirebaseDatabase.getInstance().getReference("Orders").child(acceptedOrder.UID)
                        .child(acceptedOrder.id).child("orderStatus").setValue(newOrderStatus).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), newOrderStatus, Toast.LENGTH_SHORT).show();
                        addOrderToCompletedDatabase(orderPosition);
                        acceptedOrderArrayList.get(orderPosition).orderStatus=newOrderStatus;
                        acceptedOrdersAdapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }
    void pickOrder(int orderPosition, String newOrderStatus){
        changeOrderStatusInDatabase(orderPosition,newOrderStatus);
    }
    void changeOrderStatusInDatabase(int orderPosition,String newOrderStatus){
        ReadyForDeliveryOrder acceptedOrder=acceptedOrderArrayList.get(orderPosition);
        FirebaseDatabase.getInstance().getReference("ReadyForDelivery").child(acceptedOrder.id)
                .child("orderStatus").setValue(newOrderStatus).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                FirebaseDatabase.getInstance().getReference("Orders").child(acceptedOrder.UID)
                        .child(acceptedOrder.id).child("orderStatus").setValue(newOrderStatus).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(getApplicationContext(), newOrderStatus, Toast.LENGTH_SHORT).show();
                        acceptedOrderArrayList.get(orderPosition).orderStatus=newOrderStatus;
                        acceptedOrdersAdapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.delivery_person_accept_order,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info= (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String orderId=readyForDeliveryOrderArrayList.get(info.position).id;
        int orderPosition=info.position;
        switch(item.getItemId()){
            case R.id.ctx_accptOrder:
                acceptOrder(orderPosition);
                break;

        }
        return super.onContextItemSelected(item);
    }

    void acceptOrder(int orderPosition){
        String dpid= FirebaseAuth.getInstance().getUid();
        ReadyForDeliveryOrder readyForDeliveryOrder=readyForDeliveryOrderArrayList.get(orderPosition);

        FirebaseDatabase.getInstance().getReference("ReadyForDelivery").child(readyForDeliveryOrder.id).
                child("dpid").setValue(dpid).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                FirebaseDatabase.getInstance().getReference("Orders").child(readyForDeliveryOrder.UID).
                        child(readyForDeliveryOrder.id).child("orderStatus").setValue("Assigned To Delivery Person").addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        FirebaseDatabase.getInstance().getReference("ReadyForDelivery").child(readyForDeliveryOrder.id)
                                .child("orderStatus").setValue("Assigned To Delivery Person");

                        Toast.makeText(getApplicationContext(), "Successflly acceted Order", Toast.LENGTH_SHORT).show();
                        readyForDeliveryOrderArrayList.remove(orderPosition);
                        readyForDeliveryOrderAdapter.notifyDataSetChanged();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }


}