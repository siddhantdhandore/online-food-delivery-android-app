package com.example.onlinefooddeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class DeliveryPersonProfileActivity extends AppCompatActivity {
    Button btn_deliveryPendingButton,btn_deliveryCompletedButton,btn_logout;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_person_profile);
        firebaseAuth=FirebaseAuth.getInstance();
        btn_deliveryCompletedButton=(Button) findViewById(R.id. btn_deliveryCompletedOrdersButton);
        btn_deliveryPendingButton=(Button) findViewById(R.id.btn_deliveryPendingOrdersButton);
        btn_logout=(Button)findViewById(R.id.btn_logout);

        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                finish();
            }
        });

        btn_deliveryCompletedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonProfileActivity.this, DeliveryPersonCompletedOrders.class);
                startActivity(intent);
                finish();
            }
        });

        btn_deliveryPendingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeliveryPersonProfileActivity.this, DeliveryPersonPendingOrders.class);
                startActivity(intent);
                finish();
            }
        });
    }
}