package com.example.onlinefooddeliveryapp;

public class Item {
    String id;
    String name;
    int fullPrice;
    int halfPrice;
    String description;
    boolean available;
    String downloadURI;

    public Item() {
        //required by firebase
    }

    public Item(String id, String name, int fullPrice, int halfPrice, String description, boolean available, String downloadURI) {
        this.id = id;
        this.name = name;
        this.fullPrice = fullPrice;
        this.halfPrice = halfPrice;
        this.description = description;
        this.available = available;
        this.downloadURI = downloadURI;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFullPrice() {
        return fullPrice;
    }

    public void setFullPrice(int fullPrice) {
        this.fullPrice = fullPrice;
    }

    public int getHalfPrice() {
        return halfPrice;
    }

    public void setHalfPrice(int halfPrice) {
        this.halfPrice = halfPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getDownloadURI() {
        return downloadURI;
    }

    public void setDownloadURI(String downloadURI) {
        this.downloadURI = downloadURI;
    }
}
