package com.example.onlinefooddeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<Item> itemArrayList;

    public ItemAdapter( Context context, int resource,ArrayList<Item> itemArrayList) {
        super(context, resource, itemArrayList);
        this.context = context;
        this.resource = resource;
        this.itemArrayList = itemArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v=convertView;
        if (v==null){
            LayoutInflater layoutInflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=layoutInflater.inflate(this.resource,parent,false);
        }


        TextView tv_itemName=(TextView) v.findViewById(R.id.tv_itemName);
        ImageView iv_itemImage=(ImageView) v.findViewById(R.id.iv_itemImage);
        TextView tv_itemDescription=(TextView) v.findViewById(R.id.tv_itemDescription);
        TextView tv_fullPrice=(TextView) v.findViewById(R.id.tv_fullPrice);
        TextView tv_halfPrice=(TextView) v.findViewById(R.id.tv_halfPrice);

        tv_itemName.setText(itemArrayList.get(position).name);
        Picasso.get().load(itemArrayList.get(position).downloadURI).placeholder(R.mipmap.ic_launcher).fit().into(iv_itemImage);
        tv_itemDescription.setText(itemArrayList.get(position).description);
        tv_fullPrice.setText("Full : "+itemArrayList.get(position).fullPrice);
        tv_halfPrice.setText("Half : "+itemArrayList.get(position).halfPrice);
        return v;
    }
}
