package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    //Firebase Essentials
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReferenceUsers,databaseReferenceRoles,databaseReferenceMobiles;

    //UI Controls
    EditText et_loginEmail, et_loginPassword;
    Button btn_login;
    TextView tv_forgotPassword, tv_signUp, tv_viewCurrentUser;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Firebase Instantiation
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReferenceUsers= FirebaseDatabase.getInstance().getReference("Users");
        databaseReferenceRoles= FirebaseDatabase.getInstance().getReference("Roles");
        databaseReferenceMobiles= FirebaseDatabase.getInstance().getReference("Mobiles");

        //check if user is already logged in
        String currentUID=firebaseAuth.getUid();
        if(currentUID==null){
            Toast.makeText(getApplicationContext(), "nobody logged in", Toast.LENGTH_SHORT).show();
        }else{
            loginCurrentUser();
        }
        //UI Controls
        et_loginEmail = (EditText) findViewById(R.id.et_loginEmail);
        et_loginPassword = (EditText) findViewById(R.id.et_loginPassword);
        btn_login = (Button) findViewById(R.id.btn_login);
        tv_forgotPassword = (TextView) findViewById(R.id.tv_forgotPassword);
        tv_signUp = (TextView) findViewById(R.id.tv_signUp);
        tv_viewCurrentUser=(TextView) findViewById(R.id.tv_viewCurrentUser);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get input from user
                inputValidation();
                //validate input from user
                //signin
            }
        });
        tv_forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=et_loginEmail.getText().toString().trim();
                String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if( !email.matches(emailPattern) || email.length()<7){
                    Toast.makeText(getApplicationContext(), "Invalid Email", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog=new ProgressDialog(MainActivity.this);
                    progressDialog.setCancelable(false);
                    progressDialog.setMessage("Please Wait...");
                    progressDialog.show();
                    firebaseAuth.sendPasswordResetEmail(email).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Password Reset Email has been sent.!", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        tv_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
            }
        });

        tv_viewCurrentUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Current User : "+firebaseAuth.getUid(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    void inputValidation(){
        String email=et_loginEmail.getText().toString().trim();
        String password=et_loginPassword.getText().toString().trim();
        if(email.length()<3 || password.length()<8){
            Toast.makeText(getApplicationContext(), "Invalid input", Toast.LENGTH_SHORT).show();
        }else{
            progressDialog=new ProgressDialog(MainActivity.this);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
            signInUser(email,password);
        }
    }
    void signInUser(String email, String password){
        firebaseAuth.signInWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {

                String UID=firebaseAuth.getUid();
                startActivityByRole(UID);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    void startActivityByRole(String UID){
        databaseReferenceRoles.child(UID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String userRole=snapshot.getValue(String.class);
                if(userRole.equals("Admin")){
                    progressDialog.dismiss();
                    Intent intent=new Intent(MainActivity.this, AdminDashboardMenu.class);
                    startActivity(intent);
                }else if(userRole.equals("Customer")){
                    progressDialog.dismiss();
                    Intent intent=new Intent(MainActivity.this, CustomerDashboardMenu.class);
                    startActivity(intent);
                }else if(userRole.equals("Delivery Person")){
                    progressDialog.dismiss();
                    Intent intent=new Intent(MainActivity.this, DeliveryPersonCompletedOrders.class);
                    startActivity(intent);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    void loginCurrentUser(){
        String UID=firebaseAuth.getUid();
        if(!UID.equals(null)) {
            progressDialog=new ProgressDialog(MainActivity.this);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("Please Wait...");
            progressDialog.show();
            startActivityByRole(UID);
        }else{
            Toast.makeText(getApplicationContext(), UID, Toast.LENGTH_SHORT).show();
        }
    }
}