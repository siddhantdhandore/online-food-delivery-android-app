package com.example.onlinefooddeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PendingOrderAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<CustomerOrder> pendingOrderArrayList;

    public PendingOrderAdapter( Context context, int resource,ArrayList<CustomerOrder> pendingOrderArrayList) {
        super(context, resource, pendingOrderArrayList);
        this.context = context;
        this.resource = resource;
        this.pendingOrderArrayList = pendingOrderArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v=convertView;
        if (v==null){
            LayoutInflater layoutInflater= (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v=layoutInflater.inflate(this.resource,parent,false);
        }


        TextView tv_orderId=(TextView) v.findViewById(R.id.tv_orderId);
        TextView tv_orderGrandTotalAmount=(TextView) v.findViewById(R.id.tv_orderGrandTotalAmount);
        TextView tv_orderItemString=(TextView) v.findViewById(R.id.tv_orderItemString);
        TextView tv_orderStatus=(TextView) v.findViewById(R.id.tv_orderStatus);

        tv_orderId.setText("OrderID : #"+pendingOrderArrayList.get(position).id);
        tv_orderGrandTotalAmount.setText("Grand Total "+pendingOrderArrayList.get(position).grandTotalAmount);
        tv_orderItemString.setText(pendingOrderArrayList.get(position).cartItemString);
        tv_orderStatus.setText(pendingOrderArrayList.get(position).orderStatus);
        return v;
    }
}
