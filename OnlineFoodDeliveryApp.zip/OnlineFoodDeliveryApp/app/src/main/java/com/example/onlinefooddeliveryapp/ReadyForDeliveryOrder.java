package com.example.onlinefooddeliveryapp;

public class ReadyForDeliveryOrder {
    String id;
    String deliveryAddress;
    int grandTotalAmount;
    String mobileNumber;
    String orderStatus;
    String customerName;
    String UID;
    String dpid;

    public ReadyForDeliveryOrder() {
    }

    public ReadyForDeliveryOrder(String id, String deliveryAddress, int grandTotalAmount, String mobileNumber,String customerName, String orderStatus,String UID,String dpid) {
        this.id = id;
        this.deliveryAddress = deliveryAddress;
        this.grandTotalAmount = grandTotalAmount;
        this.mobileNumber = mobileNumber;
        this.customerName=customerName;
        this.orderStatus = orderStatus;
        this.UID=UID;
        this.dpid=dpid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public int getGrandTotalAmount() {
        return grandTotalAmount;
    }

    public void setGrandTotalAmount(int grandTotalAmount) {
        this.grandTotalAmount = grandTotalAmount;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    public String getCustomerName() {
        return this.customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getUID(){
        return this.UID;
    }
    public void setUID(String UID){
        this.UID=UID;
    }
    public String getDpid(){
        return this.dpid;
    }
    public void setDpid(String dpid){
        this.dpid=dpid;
    }
}
