package com.example.onlinefooddeliveryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ReadyForDeliveryOrderAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<ReadyForDeliveryOrder> readyForDeliveryOrderArrayList;

    public ReadyForDeliveryOrderAdapter(Context context, int resource, ArrayList<ReadyForDeliveryOrder> readyForDeliveryOrderArrayList) {
        super(context, resource, readyForDeliveryOrderArrayList);
        this.context = context;
        this.resource = resource;
        this.readyForDeliveryOrderArrayList = readyForDeliveryOrderArrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = layoutInflater.inflate(this.resource, parent, false);
        }


        TextView tv_orderId = (TextView) v.findViewById(R.id.tv_orderId);
        TextView tv_grandTotal = (TextView) v.findViewById(R.id.tv_grandTotal);
        TextView tv_orderStatus = (TextView) v.findViewById(R.id.tv_orderStatus);
        TextView tv_address = (TextView) v.findViewById(R.id.tv_address);
        TextView tv_mobile = (TextView) v.findViewById(R.id.tv_mobile);
        TextView tv_customerName = (TextView) v.findViewById(R.id.tv_customerName);


        tv_orderId.setText(readyForDeliveryOrderArrayList.get(position).id);
        tv_grandTotal.setText(""+readyForDeliveryOrderArrayList.get(position).grandTotalAmount);
        tv_orderStatus.setText(readyForDeliveryOrderArrayList.get(position).orderStatus);
        tv_address.setText(readyForDeliveryOrderArrayList.get(position).deliveryAddress);
        tv_mobile.setText(readyForDeliveryOrderArrayList.get(position).mobileNumber);
        tv_customerName.setText(readyForDeliveryOrderArrayList.get(position).customerName);

        return v;
    }
}
