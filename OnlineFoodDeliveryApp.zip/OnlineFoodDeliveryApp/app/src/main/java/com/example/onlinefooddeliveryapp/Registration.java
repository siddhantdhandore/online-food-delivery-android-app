package com.example.onlinefooddeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Registration extends AppCompatActivity {
    //Firebase Essentials
    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReferenceUsers,databaseReferenceRoles,databaseReferenceMobiles;

    EditText et_registrationName, et_registrationEmail,et_registrationMobile,et_registrationPassword1,et_registrationPassword2;
    Spinner spinner_userRole;
    Button btn_register;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        firebaseAuth=FirebaseAuth.getInstance();

        databaseReferenceUsers= FirebaseDatabase.getInstance().getReference("Users");
        databaseReferenceRoles= FirebaseDatabase.getInstance().getReference("Roles");
        databaseReferenceMobiles= FirebaseDatabase.getInstance().getReference("Mobiles");

        et_registrationName=(EditText)  findViewById(R.id.et_registrationName);
        et_registrationEmail=(EditText) findViewById(R.id.et_registrationEmail);
        et_registrationMobile=(EditText) findViewById(R.id.et_registrationMobile);
        et_registrationPassword1=(EditText) findViewById(R.id.et_registrationPassword1);
        et_registrationPassword2=(EditText) findViewById(R.id.et_registrationPassword2);
        spinner_userRole=(Spinner) findViewById(R.id.spinner_userRole);
        btn_register=(Button) findViewById(R.id.btn_register);

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputValidation();
            }
        });
    }
    void inputValidation(){
        String name=et_registrationName.getText().toString().trim();
        String email=et_registrationEmail.getText().toString().trim();
        String mobile=et_registrationMobile.getText().toString().trim();
        String password1=et_registrationPassword1.getText().toString().trim();
        String password2=et_registrationPassword2.getText().toString().trim();
        String userRole=spinner_userRole.getSelectedItem().toString();
        String emailPattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if(name.length()==0 ||  email.length()==0 || mobile.length()==0 || password1.length()==0 || password2.length()==0 || userRole.equals("Select Role")){
            Toast.makeText(getApplicationContext(), "All Fields are required", Toast.LENGTH_SHORT).show();
        }else if(name.length()<3){
            Toast.makeText(getApplicationContext(), "Name should be atleast 3 chars long", Toast.LENGTH_SHORT).show();
        }else if( (!email.matches(emailPattern)) || (email.length()<7) ){
            Toast.makeText(getApplicationContext(), "Invalid Email", Toast.LENGTH_SHORT).show();
        }else if(!mobile.matches("[0-9]{10}")){
            Toast.makeText(getApplicationContext(), "Invalid Mobile", Toast.LENGTH_SHORT).show();
        }else if(password1.length()<8){
            Toast.makeText(getApplicationContext(), "Email should be at least 8 chars long", Toast.LENGTH_SHORT).show();
        }else if(!password1.equals(password2)){
            Toast.makeText(getApplicationContext(), "Password dont match", Toast.LENGTH_SHORT).show();
        }else{
            //1) check if mobile already exists
            progressDialog= new ProgressDialog(Registration.this);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("Please Wait...");
            progressDialog.setIndeterminate(true);
            progressDialog.show();
            databaseReferenceMobiles.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild(mobile)){
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Mobile already exists", Toast.LENGTH_SHORT).show();
                        }else{
                            createUser(name,email,mobile,password1,userRole);
                        }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), ""+error.toString(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    void createUser(String name,String email,String mobile,String password, String userRole){
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {

            @Override
            public void onSuccess(AuthResult authResult) {
                String UID= firebaseAuth.getUid();

                User user= new User(UID,name,email,mobile,userRole);

                databaseReferenceUsers.child(UID).setValue(user);
                databaseReferenceMobiles.child(user.mobile).setValue(UID);
                databaseReferenceRoles.child(UID).setValue(user.role);
                //1)insert created user in database
                //2)insert mobile in database
                //3) insert role in database
                firebaseAuth.signOut();
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}