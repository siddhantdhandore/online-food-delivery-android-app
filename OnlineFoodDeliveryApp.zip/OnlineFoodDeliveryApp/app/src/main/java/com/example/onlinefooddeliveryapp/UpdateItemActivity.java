package com.example.onlinefooddeliveryapp;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class UpdateItemActivity extends AppCompatActivity {
    EditText et_itemName,et_itemFullPrice,et_itemHalfPrice,et_itemDescription;
    Button btn_chooseImage,btn_updateItem;
    ImageView iv_imageSelected;

    Uri imageUri;
    ActivityResultLauncher<String> getContent;

    DatabaseReference databaseReference;
    StorageReference storageReference;
    String itemId,itemName,itemDescription,downloadURI;
    int itemFullPrice,itemHalfPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_item);

        itemId=getIntent().getStringExtra("itemid");
        itemName=getIntent().getStringExtra("itemName");

        itemFullPrice=Integer.parseInt(getIntent().getStringExtra("itemFullPrice"));
        itemHalfPrice=Integer.parseInt(getIntent().getStringExtra("itemHalfPrice"));

        itemDescription=getIntent().getStringExtra("itemDescription");
        downloadURI=getIntent().getStringExtra("downloadURI");

        databaseReference= FirebaseDatabase.getInstance().getReference("Items");

        et_itemName=(EditText) findViewById(R.id.et_itemName);
        et_itemFullPrice=(EditText) findViewById(R.id.et_itemFullPrice);
        et_itemHalfPrice=(EditText) findViewById(R.id.et_itemHalfPrice);
        et_itemDescription=(EditText) findViewById(R.id.et_itemDescription);
        btn_chooseImage=(Button) findViewById(R.id.btn_chooseImage);
        btn_updateItem=(Button) findViewById(R.id.btn_updateItem);
        iv_imageSelected=(ImageView) findViewById(R.id.iv_imageSelected);

        et_itemName.setText(itemName);
        et_itemFullPrice.setText(""+itemFullPrice);
        et_itemHalfPrice.setText(""+itemHalfPrice);
        et_itemDescription.setText(itemDescription);
        Picasso.get().load(downloadURI).placeholder(R.mipmap.ic_launcher).fit().into(iv_imageSelected);

        Log.i("itemID",itemId);
        Log.i("itemName",itemName);
        Log.i("itemFullPrice",""+itemFullPrice);
        Log.i("itemHalfPrice",""+itemHalfPrice);
        Log.i("itemDescription",itemDescription);
        Log.i("downloadURI",downloadURI);

        //1) set the Entry fields from database.
        //2) set the image from database.
        //Picasso.get().load(itemArrayList.get(position).downloadURI).placeholder(R.mipmap.ic_launcher).fit().into(iv_itemImage);
        getContent=registerForActivityResult(new ActivityResultContracts.GetContent(), new ActivityResultCallback<Uri>() {
            @Override
            public void onActivityResult(Uri result) {
                imageUri=result;
                if(imageUri!=null){
                    iv_imageSelected.setImageURI(result);
                }else{
                    Toast.makeText(getApplicationContext(), "No Image Selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getContent.launch("image/*");
            }
        });

        btn_updateItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //input validation
                validateInputData();

            }
        });


    }
    void validateInputData(){
        itemName=et_itemName.getText().toString().trim();
        itemFullPrice=Integer.valueOf(et_itemFullPrice.getText().toString().trim());
        itemHalfPrice=Integer.valueOf(et_itemHalfPrice.getText().toString().trim());
        itemDescription=et_itemDescription.getText().toString().trim();

        if(itemName.length()==0 || itemFullPrice<=0 ||itemHalfPrice<=0|| itemDescription.length()==0){
            Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
        }else if(itemFullPrice< itemHalfPrice){
            Toast.makeText(getApplicationContext(), "Full Price should be larger than half", Toast.LENGTH_SHORT).show();
        }else if(imageUri==null){
            //dont change image
            updateItemNotImage();
        }else{
            //change image
            //updateItemWithImage();
            updateItemWithImage();
        }
    }
    void updateItemNotImage(){
        Item item = new Item(itemId,itemName,itemFullPrice,itemHalfPrice,itemDescription,true,downloadURI);
        databaseReference.child(itemId).setValue(item).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(getApplicationContext(), "Successfully updated", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    void updateItemWithImage(){
        ProgressDialog progressDialog= new ProgressDialog(UpdateItemActivity.this);
        //1) add item into storage
        //2) get download url
        //3) add into firebase realtime database
        storageReference= FirebaseStorage.getInstance().getReference("uploads").child(itemId);
        storageReference.delete();
        storageReference.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        String downloadURI=uri.toString();
                        Item item = new Item(itemId,itemName,itemFullPrice,itemHalfPrice,itemDescription,true,downloadURI);
                        databaseReference.child(itemId).setValue(item);
                        progressDialog.dismiss();


                        AdminDashboardMenu.itemArrayAdapter.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "Successfully inserted", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), ""+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Please Wait...");
                progressDialog.show();
            }
        });
    }

}